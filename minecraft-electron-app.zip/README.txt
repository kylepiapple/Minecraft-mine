Minecraft HTML App

How to run:

1. Install Node.js from https://nodejs.org
2. Open this folder in a terminal
3. Run:
   npm install
4. Then run:
   npm start

Your game will open as a desktop app.